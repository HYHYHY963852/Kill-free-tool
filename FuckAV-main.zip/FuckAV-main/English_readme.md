# FuckAV
## [中文](https://github.com/iframepm/FuckAV/blob/main/README.md) [English](https://github.com/iframepm/FuckAV/blob/main/English_readme.md)

[![Travis](https://img.shields.io/badge/%E7%89%88%E6%9C%AC-1.2-red)](1)  [![Travis](https://img.shields.io/badge/Time-9--13-brightgreen)](1)  [![Travis](https://img.shields.io/badge/python-3.6-brightgreen)](1)
## Instructions
 python fuckav.py
 
 input number：1
 
 input shellcode (Example：\xfc\x48\.......\x56\x78)
 
 input number
## Record
- As of  2021-8-20，bypass：360、HipsTray、McAfee、Windows denfend、Kaspersky、Symantec  VT(10/67)
- As of  2021-8-20，bypass：360、HipsTray、McAfee、Windows denfend、Symantec  VT(10/67)
- As of  2021-8-20，bypass：360、HipsTray、McAfee、Windows denfend、Kaspersky(static state)、Symantec  VT(10/67)
- As of  2021-9-23，bypass：360、HipsTray、Windows denfend、Kaspersky(static state) VT(9/67)

![image](https://z3.ax1x.com/2021/08/20/fO7itK.jpg)
![image](https://z3.ax1x.com/2021/08/20/fOqMA1.png)
![image](https://s3.bmp.ovh/imgs/2021/09/44082aac1e090b1d.png)
