# XY-AASTools-1.7
## 一款Pythone编写的免杀工具

# 使用方法:

> 1. list 查看存在的模板
> 2. show 查看当前模板需要配置的值
> 3. into + list后的模板序号 进入当前模板
> 4. set + 当前需要配置的值（每次一个)
>> e.g. set lhost 192.168.0.1
>> e.g. set output demo.go
> 5. generate 生成源代码
> 6. os-> +DOS命令 执行本地命令
> 7. where 查看当前模板的序号
> 8. exit 退出
---

# 注意:
## 请提前安装colorama `(pip3 install colorama)`

